/*
   Copyright (c) 2009-2013, Jack Poulson
   All rights reserved.

   This file is part of Elemental and is under the BSD 2-Clause License, 
   which can be found in the LICENSE file in the root directory, or at 
   http://opensource.org/licenses/BSD-2-Clause
*/
#ifndef ELEM_CONFIG_H
#define ELEM_CONFIG_H

/* Build type and version information */
#define ELEM_GIT_SHA1 "GITDIR-NOTFOUND"
#define Elemental_VERSION_MAJOR "0"
#define Elemental_VERSION_MINOR "84-dev"
#define ELEM_CMAKE_BUILD_TYPE "HybridRelease"
#define ELEM_RELEASE

/* C compiler info */
#define ELEM_CMAKE_C_COMPILER    "/usr/bin/gcc-4.8"
#define ELEM_MPI_C_COMPILER      "/usr/local/bin/mpicc"
#define ELEM_MPI_C_INCLUDE_PATH  "/usr/local/include"
#define ELEM_MPI_C_COMPILE_FLAGS ""
#define ELEM_MPI_C_LINK_FLAGS    " -Wl,-rpath  -Wl,/usr/local/lib  -Wl,--enable-new-dtags"
#define ELEM_MPI_C_LIBRARIES     "/usr/local/lib/libmpi.so"

/* C++ compiler info */
#define ELEM_CMAKE_CXX_COMPILER    "/usr/bin/g++-4.8"
#define ELEM_CXX_FLAGS             "-std=c++11 -fPIC -std=c++11 "
#define ELEM_MPI_CXX_COMPILER      "/usr/local/bin/mpicxx"
#define ELEM_MPI_CXX_INCLUDE_PATH  "/usr/local/include"
#define ELEM_MPI_CXX_COMPILE_FLAGS ""
#define ELEM_MPI_CXX_LINK_FLAGS    " -Wl,-rpath  -Wl,/usr/local/lib  -Wl,--enable-new-dtags"
#define ELEM_MPI_CXX_LIBRARIES     "/usr/local/lib/libmpi_cxx.so;/usr/local/lib/libmpi.so"

/* Math libraries */
#define ELEM_MATH_LIBS "/usr/local/flame/lib/libflame.a;-L/usr/local/lib/ -lopenblas;/lib/x86_64-linux-gnu/libm.so.6"
#define ELEM_BLAS_POST
#define ELEM_LAPACK_POST
/* #undef ELEM_HAVE_SCALAPACK */
/* #undef ELEM_SCALAPACK_POST */
#define ELEM_HAVE_FLA_BSVD
#define ELEM_FORT_LOGICAL int
#define ELEM_FORT_TRUE    1
#define ELEM_FORT_FALSE   0

/* Basic configuration options */
#define ELEM_RESTRICT __restrict__
/* #undef ELEM_HAVE_OPENMP */
#define ELEM_HAVE_OMP_COLLAPSE
/* #undef ELEM_HAVE_QT5 */
#define ELEM_HAVE_F90_INTERFACE
#define ELEM_AVOID_COMPLEX_MPI
#define ELEM_HAVE_CXX11RANDOM
#define ELEM_HAVE_STEADYCLOCK
#define ELEM_HAVE_NOEXCEPT
#define ELEM_HAVE_MPI_REDUCE_SCATTER_BLOCK
#define ELEM_HAVE_MPI_IN_PLACE
#define ELEM_HAVE_MPI_LONG_LONG
#define ELEM_HAVE_MPI_COMM_SET_ERRHANDLER
#define ELEM_HAVE_MPI_INIT_THREAD
#define ELEM_HAVE_MPI_QUERY_THREAD
#define ELEM_HAVE_MPI3_NONBLOCKING_COLLECTIVES
/* #undef ELEM_HAVE_MPIX_NONBLOCKING_COLLECTIVES */
/* #undef ELEM_REDUCE_SCATTER_BLOCK_VIA_ALLREDUCE */
#define ELEM_USE_BYTE_ALLGATHERS
/* #undef ELEM_USE_64BIT_INTS */

/* Advanced configuration options */
/* #undef ELEM_CACHE_WARNINGS */
/* #undef ELEM_UNALIGNED_WARNINGS */
/* #undef ELEM_VECTOR_WARNINGS */
/* #undef ELEM_POOL_MEMORY */
/* #undef ELEM_AVOID_OMP_FMA */

#endif /* ELEM_CONFIG_H */
